//
//  TWTRIdentifier.h
//  TwitterKit
//
//  Created by Kang Chen on 11/12/14.
//  Copyright (c) 2014 Twitter. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString *TWTRIdentifierForAdvertising();

/**
 *  This class contains analytics code ported from Crashlytics.
 */
@interface TWTRIdentifier : NSObject

@end
